<?php
error_reporting(0);

require_once 'classes/RestServer.php';

$restServer = new RestServer();
$restServer->handle();