<?php
/**
 * Генератор выдачи в формате json
 *
 * @author Bujinov Andrei
 */
class JsonView extends GenericView{
    public function render($content) {
        header('Content-Type: application/json; charset=utf8');
        die(json_encode($content));
    }
}
