<?php
/**
 * Контроллер для работы с мейлбоксами (папками)
 *
 * @author Bujinov Andrei
 */
class FolderController extends GenericController{
    const ID_FOLDER_SPAM = 1;
    const ID_FOLDER_TRASH = 2;
    const ERROR_MSG_FOLDER_NOT_FOUND = "Folder not found";
    const ERROR_MSG_INVALID_INPUT_FOLDER = "Unknown mailbox supplied ";
    const ERROR_MSG_COULD_NOT_UPDATE_FOLDER = "Could not update folder";
    
    /**
     * Возвращает список всех папок (для построения меню)
     */
    public function actionGetList() {
        $data = FolderModel::findAll();
        $outData = [];
        foreach($data as $item){
            $outData[] = FolderDao::cast($item);
        }
        $this->render($outData);
    }
    /**
     * Сохраняет в базе gmail-овый путь к папке (корзина или спам), для дальнейших обращений к ней
     * это нужно потому что для папок (корзина или спам) у гугла нет алиаса, и путь к этой папке 
     * зависит от языка интерфейса в ящике
     */
    public function actionPostMailbox() {
        $requestParameters = self::getRequest()->getParameters();
        $mailboxName = $requestParameters['mailboxName'];
        switch($mailboxName){
            case "spam":
                $id = self::ID_FOLDER_SPAM;
                break;
            case "trash":
                $id = self::ID_FOLDER_TRASH;
                break;
            default:
                $this->renderStatusError(self::ERROR_MSG_INVALID_INPUT_FOLDER . $mailboxName);
                return;
        }
        $folder = FolderModel::findById($id);
        if(!($folder instanceof FolderModel))
            $this->renderStatusError(self::ERROR_MSG_FOLDER_NOT_FOUND);            
        
        //если старый путь совпадает с новым, то ничего не делаем
        if($requestParameters['gmailName'] == $folder->getGmailName())
            $this->renderStatusSuccess();
        
        $folder->setGmailName($requestParameters['gmailName']);
                
        if($folder->update())
            $this->renderStatusSuccess();
        else
            $this->renderStatusError(self::ERROR_MSG_COULD_NOT_UPDATE_FOLDER);
    }
}
