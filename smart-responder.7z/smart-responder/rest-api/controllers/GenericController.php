<?php
/**
 * АрхиКонтроллер, папа всех контроллеров )
 *
 * @author Bujinov Andrei
 */
class GenericController {
    /**
     * Генератор output-а
     * 
     * @var GenericView
     */
    private $view;
            
    function __construct() {
        $this->view = new JsonView();
    }

    /**
     * @return Request
     */
    public static function getRequest(){
        return Request::getInstance();
    }
    
    public function setView(GenericView $view) {
        $this->view = $view;
    }

    public function render($content) {
        $this->view->render($content);
    }
    
    public function renderStatusSuccess() {
        $this->view->renderStatusSuccess();
    }

    public function renderStatusError($msg) {
        $this->view->renderStatusError($msg);
    }
}