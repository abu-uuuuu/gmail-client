<?php
/**
 * Контроллер для работы с письмами из БД
 *
 * @author Bujinov Andrei
 */
class MailController extends GenericController{
    const ERROR_MSG_MAIL_NOT_FOUND = "Mail not found";
    const ERROR_MSG_COULD_NOT_DELETE_MAIL = "Could not delete mail from DB";
    
    /**
     * Возвращает список писем из заданной папки
     */
    public function actionGetList($folderName) {
        $data = MailModel::findByFolder($folderName);
        $outData = [];
        foreach($data as $item){
            $outData[] = MailFolderedDao::cast($item);
        }
        $this->render($outData);
    }
    /**
     * Возвращает письмо по заданному id
     */
    public function actionGetView($id) {
        $mail = MailModel::findById($id);
        if(!($mail instanceof MailModel))
            $this->renderStatusError(self::ERROR_MSG_MAIL_NOT_FOUND);            
        
        $this->render(MailDao::cast($mail));
    }
    /**
     * Удаляет заданное письмо из БД
     */
    public function actionDeleteDelete($id) {
        $mail = MailModel::findById($id);
        if(!($mail instanceof MailModel))
            $this->renderStatusError(self::ERROR_MSG_MAIL_NOT_FOUND);            
        
        if($mail->delete() == 1)
            $this->renderStatusSuccess();
        else
            $this->renderStatusError(self::ERROR_MSG_COULD_NOT_DELETE_MAIL);
    }
}