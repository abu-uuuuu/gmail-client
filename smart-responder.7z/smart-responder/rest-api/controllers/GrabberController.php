<?php
/**
 * Контроллер для работы с граббером (для обращений к gmail-овой почте через imap)
 *
 * @author Bujinov Andrei
 */
class GrabberController extends GenericController{
    const ERROR_MSG_COULD_NOT_PERSIST = "Could not persist grabber configuration";
    const ERROR_MSG_COULD_NOT_GRAB = "Could not grab emails";
    
    /**
     * Сохраняет в базе настройки подключения через imap
     */
    public function actionPutPersist() {
        $requestParameters = self::getRequest()->getParameters();
        if(GrabberModel::persist(
            $requestParameters['hostname'],
            $requestParameters['username'],
            $requestParameters['password']
        ))
        {
            $this->renderStatusSuccess();
        }else{
            $this->renderStatusError(self::ERROR_MSG_COULD_NOT_PERSIST);
        }
    }
    /**
     * Удаляет из локальной БД всё, 
     * обращается к почтовым ящикам gmail и записывает каждое письмо в базу
     */
    public function actionGetGrab() {
        $grabber = new GrabberModel();
        //перед тем как грабить чистим таблицу с мейлами
        MailModel::deleteAll();
        $grabber->grab();
        $this->renderStatusSuccess();
    }    
    /**
     * Проверяет если в БД есть настройки соединения с почтой.
     * Tсли нет, юзеру надо будет их задать в GUI
     */
    public function actionGetConfigured() {
        $isConfigured = GrabberModel::isConfigured();
        $this->render(['configured'=>$isConfigured]);
    }    
    /**
     * Возвращает список всех папок с сервера
     * Чтобы задать соответствие гугловых путей местным папкам Спам и Корзина
     */
    public function actionGetMailboxes() {
        $requestParameters = self::getRequest()->getParameters();
        $data = GrabberModel::grabMailboxList(            
            $requestParameters['hostname'],
            $requestParameters['username'],
            $requestParameters['password']);

        $this->render($data);
    }    
}
