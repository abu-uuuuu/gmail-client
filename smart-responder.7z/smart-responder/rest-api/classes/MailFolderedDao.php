<?php
/**
 * Структура для выдачи письма как элемента списка
 *
 * @author Bujinov Andrei
 */
class MailFolderedDao {
    public $id;
    public $subject;
    public $date;
    public $dmarc;
    
    function __construct($id, $subject, $date, $dmarc) {
        $this->id = $id;
        $this->subject = $subject;
        $this->date = date('d/m/Y H:i', strtotime($date));
        $this->dmarc = $dmarc;
    }
    
    public static function cast(MailModel $mail){
        return new self($mail->getId(), $mail->getSubject(), $mail->getDate(), $mail->getDmarc());
    }
}
