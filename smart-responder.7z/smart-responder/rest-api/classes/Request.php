<?php
/**
 * Обработчик запросов
 *
 * @author Bujinov Andrei
 */
class Request {
    
    const METHOD_GET = 'GET';
    const METHOD_PUT = 'PUT';
    const METHOD_POST = 'POST';
    const METHOD_DELETE = 'DELETE';    
    
    private $urlParts;
    private $verb;
    private $parameters;
    
    private static $instance;

    private function __construct(){}
    
    /**
     * @return Request
     */
    public static function getInstance(){
        if(!isset(self::$instance))self::$instance = new self();
        return self::$instance;
    }
    
    function getUrlParts() {
        return $this->urlParts;
    }

    function getVerb() {
        return $this->verb;
    }
    
    function getParameters() {
        return $this->parameters;
    }

    /**
     * Разбираем url запроса, параметры и метод
     */
    public function dispatch() {
        $this->verb = $_SERVER['REQUEST_METHOD'];
        $tmp = explode('?', $_SERVER['REQUEST_URI']);
        $this->urlParts = explode('/', $tmp[0]);
        
        switch($this->verb){
            case self::METHOD_POST:
            case self::METHOD_PUT:
            {
                parse_str(file_get_contents("php://input"),$this->parameters);
                //$this->parameters = json_decode(file_get_contents("php://input"), true);
                break;
            }
            case self::METHOD_GET:
            {
                if(isset($tmp[1])){
                    parse_str($tmp[1], $this->parameters);
                }
            }
        }
    }    
}