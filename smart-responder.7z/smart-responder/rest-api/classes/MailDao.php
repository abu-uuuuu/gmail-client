<?php
/**
 * Структура для выдачи письма
 *
 * @author Bujinov Andrei
 */
class MailDao {
    public $id;
    public $from;
    public $subject;
    public $body;
    
    public function __construct($id, $from, $subject, $body) {
        $this->id = $id;
        $this->from = $from;
        $this->subject = $subject;
        $this->body = $body;
    }
    
    public static function cast(MailModel $mail){
        return new self($mail->getId(), 
                $mail->getFrom(),
                $mail->getSubject(),
                $mail->getBody()
        );
    }
}
