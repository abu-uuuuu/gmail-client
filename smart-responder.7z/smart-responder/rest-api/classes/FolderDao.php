<?php
/**
 * Структура для выдачи списка мейлбоксов
 *
 * @author Bujinov Andrei
 */
class FolderDao {
    public $name;
    public $description;
    public $url;
    
    function __construct($name, $description, $url) {
        $this->name = $name;
        $this->description = $description;
        $this->url = $url;
    }

    public static function cast(FolderModel $folder){
        return new self(
                $folder->getName(),
                $folder->getDescription(),
                $folder->getUrl()
        );
    }
}
