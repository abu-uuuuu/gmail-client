<?php
return [
		'db'=>[
			'connectionString' => 'mysql:host=localhost;dbname=smartresponder',
			'username' => 'smartresponder',
			'password' => 'smartresponder',
			'charset' => 'utf8',
		],
];