<?php
/**
 * Модель для работы с письмами в БД
 *
 * @author Bujinov Andrei
 */
class MailModel extends GenericModel{
    private $id;
    private $from;
    private $subject;
    private $body;
    private $date;
    private $idFolder;
    private $dmarc;
    
    public function __construct($id, $from, $subject, $body, $date, $idFolder, $dmarc) {
        $this->id = $id;
        $this->from = $from;
        $this->subject = $subject;
        $this->body = $body;
        $this->date = $date;
        $this->idFolder = $idFolder;
        $this->dmarc = $dmarc;
    }    
    function getId() {
        return $this->id;
    }

    function getFrom() {
        return $this->from;
    }

    function getSubject() {
        return $this->subject;
    }

    function getBody() {
        return $this->body;
    }

    function getDate() {
        return $this->date;
    }

    function getIdFolder() {
        return $this->idFolder;
    }

    function getDmarc() {
        return $this->dmarc;
    }

    /**
     * Возвращает письмо из БД по id
     */
    public static function findById($id){
        $sql = 'select `id`, `from`, `subject`, `body`, `date`, `idFolder`, `dmarc` from `email` where `id` = :id';
        $stmt = self::getDbAdapter()->execute($sql, ['id' => $id]);

        while($row = $stmt->fetch())
        {
            return new self($row['id'],$row['from'],$row['subject'],$row['body'],$row['date'],$row['idFolder'],$row['dmarc']);
        }
        return null;

    }
    /**
     * Возвращает все письма из заданной папки
     */
    public static function findByFolder($folder){
        $sql = 'select `id`, `from`, `subject`, `body`, `date`, `idFolder`, `dmarc` from `email` where `idFolder` in (select `id` from `folder` where `name` = :name ) order by `date` DESC';
        $stmt = self::getDbAdapter()->execute($sql, ['name' => $folder]);
        
        $data = [];
        while($row = $stmt->fetch())
        {
            $data[] = new self($row['id'],$row['from'],$row['subject'],$row['body'],$row['date'],$row['idFolder'],$row['dmarc']);
        }

        return $data;
    }
    /**
     * Сохраняет письмо в БД
     * @param string $from
     * @param string $subject
     * @param string $bodyPlain
     * @param string $bodyHtml
     * @param string $date
     * @param int $idFolder
     * @param int $dmarc
     * @return boolean
     */
    public static function persist($from, $subject, $bodyPlain, $bodyHtml, $date, $idFolder, $dmarc){
        $sql = 'insert into `email` set `from` = :from, `subject` = :subject, `body` = :bodyPlain, `bodyHtml` = :bodyHtml, `date` = :date, `idFolder` = :idFolder, `dmarc` = :dmarc';
        $parameters = [
            'from' => $from,
            'subject' => $subject,
            'bodyPlain' => $bodyPlain,
            'bodyHtml' => $bodyHtml,
            'date' => $date,
            'idFolder' => $idFolder,
            'dmarc' => $dmarc,
        ];
        return self::getDbAdapter()->execute($sql, $parameters)->rowCount() == 1 ? true : false;
    }
    /**
     * Удаляет письмо из БД
     * @return int
     */
    public function delete(){
        $sql = 'delete from `email` where `id` = :id';
        return self::getDbAdapter()->execute($sql, ['id' => $this->id])->rowCount();
    }
    /**
     * Удаляет все письма из БД
     * @return boolean
     */
    public static function deleteAll(){
        $sql = 'delete from `email`';
        return self::getDbAdapter()->execute($sql)->rowCount() > 0;
    }    
}
