<?php
/**
 * Модель для работы с мейлбоксами (папками) из БД
 *
 * @author Bujinov Andrei
 */
class FolderModel extends GenericModel{
    private $id;
    private $name;
    private $description;
    private $order;
    private $gmailName;
    private $url;

    function __construct($id, $name, $description, $order, $gmailName, $url) {
        $this->id = $id;
        $this->name = $name;
        $this->description = $description;
        $this->order = $order;
        $this->gmailName = $gmailName;
        $this->url = $url;        
    }

    function getId() {
        return $this->id;
    }

    function getName() {
        return $this->name;
    }

    function getDescription() {
        return $this->description;
    }

    function getOrder() {
        return $this->order;
    }

    function getGmailName() {
        return $this->gmailName;
    }
    
    function getUrl() {
        return $this->url;
    }

    function setGmailName($gmailName) {
        $this->gmailName = $gmailName;
    }

    /**
     * Возвращает все папки из БД
     */
    public static function findAll(){
        $sql = 'select `id`, `name`, `description`, `order`, `gmailName`, `url` from `folder` order by `order`';
        $stmt = self::getDbAdapter()->execute($sql);
        
        $data = [];
        while($row = $stmt->fetch())
        {
            $data[] = new self(
                    $row['id'],
                    $row['name'],
                    $row['description'],
                    $row['order'],
                    $row['gmailName'],
                    $row['url']
            );
        }

        return $data;
    }

    /**
     * Возвращает папку из БД по id
     */
    public static function findById($id){
        $sql = 'select `id`, `name`, `description`, `order`, `gmailName`, `url` from `folder` where `id` = :id';
        $stmt = self::getDbAdapter()->execute($sql, ['id' => $id]);
        
        while($row = $stmt->fetch())
        {
            return new self(
                    $row['id'],
                    $row['name'],
                    $row['description'],
                    $row['order'],
                    $row['gmailName'],
                    $row['url']
            );
        }

        return null;
    }
    
    /**
     * Сохраняет изменённые параметры папки в БД
     */
    public function update(){
        $sql = 'update `folder` set `gmailName` = :gmailName where `id` = :id';
        return self::getDbAdapter()->execute($sql, [
            'gmailName' => $this->gmailName,
            'id' => $this->id,
        ])->rowCount() == 1 ? true : false;
    }
}
