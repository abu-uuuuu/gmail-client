<?php
/**
 * Модель для работы с граббером писем
 *
 * @author Bujinov Andrei
 */
class GrabberModel extends GenericModel {
    private $hostname;
    private $username;
    private $password;
    
    function __construct() {
        $sql = 'select `hostname`, `username`, `password` from `grabber`';
        $row = self::getDbAdapter()->execute($sql)->fetch();
        
        $this->hostname = $row['hostname'];
        $this->username = $row['username'];
        $this->password = $row['password'];
    }

    /**
     * Сохраняет настройки подключения к почте в БД
     * 
     * @param string $hostname
     * @param string $username
     * @param string $password
     * @return boolean
     */
    public static function persist($hostname, $username, $password){
        //в настройках должна быть только одна запись, поэтому перед сохранением удаляем всё что есть
        self::getDbAdapter()->execute('delete from `grabber`');
        
        $sql = 'insert into `grabber` set `hostname` = :hostname, `username` = :username, `password` = :password';
        $parameters = [
            'hostname'=>  $hostname,
            'username'=>  $username,
            'password'=>  $password,
        ];
        return self::getDbAdapter()->execute($sql, $parameters)->rowCount() == 1 ? true : false;
    }
    /**
     * Возвращает список пар (value, label) почтовых папок с сервера, 
     * для построения списка для юзера (чтобы поставить в соответствие папки Спам и Корзина)
     * 
     * @param string $hostname
     * @param string $username
     * @param string $password
     * @return array
     */
    public static function grabMailboxList($hostname, $username, $password){
        $connection = imap_open($hostname,$username,$password) or die('Cannot connect to Gmail: ' . imap_last_error());
        $list = imap_getmailboxes($connection, $hostname, "*");
        $data = [];
        if (is_array($list)) {
            foreach ($list as $key => $val) {
                //echo imap_utf7_decode($val->name) . ",";
                $data[] = [
                    'value' => $val->name,
                    'label' => mb_convert_encoding($val->name, "UTF-8", "UTF7-IMAP"),
                ];
            }
        }
        imap_close($connection);
        
        return $data;
    }
    
    /**
     * Грабит письма для локальных папок и сохраняет их в БД
     */
    public function grab(){
        $folders = FolderModel::findAll();
        foreach($folders as $folder)
        {
            $this->grabByFolder($folder);
        }
    }
    
    /**
     * Грабит письма для заданной папки
     */
    private function grabByFolder(FolderModel $folder){
        $hostname = $folder->getGmailName();
        $inbox = imap_open($hostname,$this->username,$this->password) or die('Cannot connect to Gmail: ' . imap_last_error());
        $emails = imap_search($inbox,'ALL');

        if($emails) 
        {
            foreach($emails as $emailNumber) 
            {
                $overview = imap_fetch_overview($inbox,$emailNumber,0);
                $headers = imap_fetchheader($inbox,$emailNumber,FT_INTERNAL);

                $dmarc = false;
                if(preg_match("/dmarc=pass/", $headers)){
                    $dmarc = true;
                }

                //получаем subject
                $subject = '';                
                $subjectParts = imap_mime_header_decode($overview[0]->subject);                
                foreach($subjectParts as $subjectPart) {
                    $subject .= $subjectPart->charset == 'default' ? 
                            $subjectPart->text : 
                            iconv($subjectPart->charset,'UTF-8', $subjectPart->text);
                }

                //получаем body
                $bodyPlain = '';
                $bodyHtml = '';
                $st = imap_fetchstructure($inbox, $emailNumber);
                if (!empty($st->parts)) {
                    for ($i = 0, $j = count($st->parts); $i < $j; $i++) {
                        $part = $st->parts[$i];
                        if($part->subtype == 'PLAIN'){
                            $bodyPlain = $this->getDecodedImapBody($part->encoding, $inbox, $emailNumber, $i);
                        }elseif($part->subtype == 'HTML'){
                            $bodyHtml = $this->getDecodedImapBody($part->encoding, $inbox, $emailNumber, $i);
                        }
                     }
                } else {
                    $bodyPlain = imap_body($inbox, $emailNumber);
                    $bodyHtml = $bodyPlain;
                }    
                
                //сохранение в БД
                MailModel::persist(
                        $overview[0]->from, 
                        $subject,
                        $bodyPlain,
                        $bodyHtml,
                        (new DateTime($overview[0]->date))->format("Y-m-d H:i:s"), 
                        $folder->getId(),
                        $dmarc);
            }
        } 

        imap_close($inbox);  
    }
    
    private function getDecodedImapBody($encoding, $mailbox, $emailNumber, $partIndex){
        if($encoding == "3"){
            return base64_decode(imap_fetchbody($mailbox, $emailNumber, $partIndex+1));
        }
        elseif($encoding == "4"){
            return imap_qprint(imap_fetchbody($mailbox, $emailNumber, $partIndex+1));
        }else{
            return imap_fetchbody($mailbox, $emailNumber, $partIndex+1);
        }        
    }
    
    /**
     * Возвращает true если настройки соединения присутствуют в базе
     * @return boolean
     */
    public static function isConfigured(){
        $sql = 'select * from `grabber`';
        return self::getDbAdapter()->execute($sql)->rowCount() == 1 ? true : false;
    }
}
