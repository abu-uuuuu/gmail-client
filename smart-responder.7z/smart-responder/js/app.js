var folders = {
    inbox: 'inbox',
    spam: 'spam',
    trash: 'trash'
};
var menuItems = [];

var services = {
    getMenuItems: function(callback){
        var url = 'rest-api/folder/list';
        this.callGetRest(url, callback);
    },
    getEmailsByFolder: function(folder, callback){
        var url = this.getMailboxUrl(folder);
        if(url === undefined)return;
        this.callGetRest(url, callback);
    },
    getEmailById: function(emailId, callback){
        var url = 'rest-api/mail/view/' + emailId;
        this.callGetRest(url, callback);
    },
    deleteEmailById: function(emailId, callback){
        var url = 'rest-api/mail/delete/' + emailId;
        $.ajax(url,{method: 'DELETE'})
          .done(callback)
          .fail(this.onRequestFail);
    },
    getGrabberConfigured: function(callback){
        var url = 'rest-api/grabber/configured';
        this.callGetRest(url, callback);
    },
    getServerMailboxes: function(data, callback){
        var url = 'rest-api/grabber/mailboxes';
        $.ajax(url,{method: 'GET', data: data})
          .done(callback)
          .fail(this.onRequestFail);
    },
    getGrabberGrab: function(callback){
        var url = 'rest-api/grabber/grab';
        this.callGetRest(url, callback);
    },
    putGrabberPersist: function(data, callback){
        var url = 'rest-api/grabber/persist';
        $.ajax(url,{method: 'PUT', data: data})
          .done(callback)
          .fail(this.onRequestFail);
    },
    postMailBox: function(data, callback){
        var url = 'rest-api/folder/mailbox';
        $.ajax(url,{method: 'POST', data: data})
          .done(callback)
          .fail(this.onRequestFail);
    },
    callGetRest: function(url, callback){
        //загрузка через вызов rest
        $.getJSON(url)
          .done(callback)
          .fail(this.onRequestFail);
    },
    getMailboxUrl: function(folder){
        for(var i=0; i < menuItems.length; i++){
            if(menuItems[i].name == folder){
                    return menuItems[i].url;
            }
        }
        console.log("Invalid folder " + folder);
    },
    onRequestFail: function( jqxhr, textStatus, error ){
        var err = textStatus + ", " + error;
        console.log( "Request Failed: " + err );
    }
};
//обработка выбора пункта из меню
function menuItemClicked(){
    $('#menu .list-group-item').removeClass('active');
    $(this).addClass('active');
    var folder = $(this).data('folder');
    //загружаем список писем выбранной папки
    loadMailBox(folder);
}
//очистка блока данных для списка писем или содержания письма
function clearContent(){
    $('#content').html('');
}
//загрузка списка писем
function loadMailBox(folder){
    clearContent();
    //получаем список писем с сервера для папки
    services.getEmailsByFolder(folder, function(data){
        //загружаем полученный список
        if(data.length === 0){
            $("<div/>", {
              html: "Нет данных."
            }).appendTo("#content");
            return;
        }
        $("<table/>", {
          "class": "email-list table",
          html: $("#mailListItemTemplate").tmpl(data)
        }).appendTo("#content");
            $(".email-list td[data-dmarc=1]").append("<code>dmarc</code>");
    });
}
//загрузка содержания письма
function emailListItemClicked(){
    var emailId = $(this).parent('tr').data('emailId');
    if(emailId === undefined){
        console.log('invalid emailId');
        return;
    }
    //подготовка remove button
    $('#remove-email-button').data('emailId', emailId);
    //если выбрали удаление, содержимое не загружаем
    if($(this).hasClass('email-actions')){
      return;
    }
    //загружаем само письмо из сервиса
    clearContent();
    services.getEmailById(emailId, function(data){
        $("<div/>", {
          "class": "message",
          html: $("#mailDetailsTemplate").tmpl(data)
        }).appendTo("#content");
    });
}
function showErrorModal(){
    $('#generic-error-modal').modal('show');	
}
//закрываем confirmation popup для удаления письма и вызываем ф-цию удаления из базы
function removeEmailClicked(){
    $('#confirm-remove-modal').modal('hide');
	
    var emailId = $('#remove-email-button').data('emailId');
    services.deleteEmailById(emailId, function(data){
        //после удаления показываем соотв. подтверждение
        if(data.status === 'OK'){
            $('#remove-success-modal').modal('show');
            reloadMailBox();
        }else{
            showErrorModal();
        }
    });
}
function reloadMailBox(){
    loadMailBox($('#menu .list-group-item.active').data('folder'));
}
//строим меню из загруженных папок
function createMenu(data){
    menuItems = data;
    //добавляем меню
    $("<div/>", {
      "class": "list-group",
      html: $("#menuListItemTemplate").tmpl(menuItems)
    }).appendTo("#menu");
    //устанавливаем активный пункт меню
    $('#menu .list-group-item[data-folder="' + folders.inbox + '"]').addClass('active');
    //загружаем список писем для выбранной по умолчанию папки
    loadMailBox($('#menu .list-group-item.active').data('folder'));
}
//если есть настройки, загружаем папки, строим меню и загружаем список писем
//иначе выдаем попап для создания соединения
function grabberConfiguredCallback(data){
    if(data.configured === true){
        //построение меню
        services.getMenuItems(createMenu);
    }else{
        $('#grabber-settings-modal').modal('show');
    }
}
//валидация и сохранение настроек для соединения с почтовым сервером
function grabberSettingsSaveButtonClicked(){
    var allItemsAreFilled = $('#grabber-settings-form [required]').length > 0;
    $('#grabber-settings-form [required]').each(function(){
        if($(this).val() === ''){
            allItemsAreFilled = false;
            return;
        }
    });
    //сохраняем настройки в базу
    if(allItemsAreFilled){
        services.postMailBox({
            mailboxName:folders.spam,
            gmailName:$('#folder-spam').val()
        }, function(data){
            services.postMailBox({
                mailboxName:folders.trash,
                gmailName:$('#folder-trash').val()
            }, function(data){
                services.putGrabberPersist(
                    {
                        hostname: $('#hostname').val(),
                        username: $('#username').val(),
                        password: $('#password').val()
                    },
                    function(data){
                        if(data.status !== 'OK'){
                            showErrorModal();
                            return;
                        }
                        //после сохранения настроек запускаем граббер
                        $('#grabber-settings-modal').modal('hide');
                        $('#content').html('Ожидайде, идёт получение писем с сервера, это может длиться долго...');

                        services.getGrabberGrab(function(data){
                            initApp();
                        });                
                    }
                );
            });
        });
    }
}
//инициализируем поведение контролов в попапе для настроек соединения
function formFieldsInitBehavior(){
    $('body').on('focusout', 'input[required],select[required]', function(){
        if($(this).val() === '' && !($(this).hasClass('has-error'))){
            $(this).parents('.form-group').addClass('has-error');
        }else{
            $(this).parents('.form-group').removeClass('has-error');
        }
    });
    //заполняем списки серверных папок
    $('body').on('focusout', '#grabber-settings-form [data-group="connection-group"]', function(){
        //если заполнена группа полей для коннекта с сервером, тогда можем вытащить список серверных папок
        var allGroupItemsAreFilled = $('#grabber-settings-form [data-group="connection-group"]').length > 0;
        $('#grabber-settings-form [data-group="connection-group"]').each(function(){
            if($(this).val() === ''){
                allGroupItemsAreFilled = false;
                return;
            }
        });
        //очищаем списки
        $('#folder-spam').empty();
        $('#folder-trash').empty();
        //загружаем списки серверных папок
        if(allGroupItemsAreFilled){
            var parameters = {
                hostname:$('#hostname').val(),
                username:$('#username').val(),
                password:$('#password').val()
            };
            services.getServerMailboxes(parameters,function(data){
                //загружаем options в select-ы для папки спам и корзина
                var options = '';
                $.each(data, function(i, item){
                    options += '<option value="' + item.value + '">' + item.label + '</option>';
                });

                $('#folder-spam').append(options);
                $('#folder-trash').append(options);
            });
        }
    });
}
//проверяем если сконфигурировано подключение IMAP
function initApp(){
    services.getGrabberConfigured(grabberConfiguredCallback);
}
//начало всех начал
$(function(){
    //загрузка всплывающих сообщений
    $('<div/>').appendTo('body').load('/parts/messages.html');
    //загрузка шаблонов для построения списка писем и тела письма
    $('<div/>').appendTo('body').load('/parts/templates.html', initApp);

    //выбор папки из меню
    $('#menu').on('click', '.list-group-item', menuItemClicked);
    //выбор самого письма из списка для загрузки его содержимого
    $('#content').on('click', 'table.email-list td', emailListItemClicked);
    //удаление письма
    $('body').on('click', '#remove-email-button', removeEmailClicked);
    $('body').on('click', '#grabber-settings-save-button', grabberSettingsSaveButtonClicked);
    //подсветка обязательных полей
    formFieldsInitBehavior();
});