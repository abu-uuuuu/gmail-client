/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.1.73-community : Database - smartresponder
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`smartresponder` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `smartresponder`;

/*Table structure for table `email` */

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `idFolder` smallint(6) NOT NULL,
  `bodyHtml` text COLLATE utf8_unicode_ci,
  `dmarc` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `I01_idFolder` (`idFolder`),
  CONSTRAINT `FK01_email_folder` FOREIGN KEY (`idFolder`) REFERENCES `folder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `email` */

/*Table structure for table `folder` */

DROP TABLE IF EXISTS `folder`;

CREATE TABLE `folder` (
  `id` smallint(6) NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(6) DEFAULT NULL,
  `gmailName` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `I01_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `folder` */

insert  into `folder`(`id`,`name`,`description`,`order`,`gmailName`,`url`) values (0,'inbox','Входящие',0,'{imap.gmail.com:993/imap/ssl}INBOX','rest-api/mail/list/inbox'),(1,'spam','Спам',1,'{imap.gmail.com:993/imap/ssl}[Gmail]/&BCEEPwQwBDw-','rest-api/mail/list/spam'),(2,'trash','Корзина',2,'{imap.gmail.com:993/imap/ssl}[Gmail]/&BBoEPgRABDcEOAQ9BDA-','rest-api/mail/list/trash');

/*Table structure for table `grabber` */

DROP TABLE IF EXISTS `grabber`;

CREATE TABLE `grabber` (
  `hostname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hostname`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `grabber` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
